from django.shortcuts import redirect, render
from students.models import student

def home(request):
    Student=student.objects.all()
    return render(request, "home.html", {'Student': Student})
    



def formm(request):
    if request.method=='POST':
        name=request.POST['name']   #use in 2 diffrent methos ... using post [] or post.get........return none if key isnt found / use get ifpotenial key may not present post for direct 
        address=request.POST['address']
        rank=request.POST['rank']
        Student=student.objects.create(name=name, address=address, rank=rank)
        # Student.save()
        return redirect('home')
    return render(request,"form.html")
   
def delete(request, delete_id):
    Student=student.objects.get(id=delete_id)
    Student.delete()
    return redirect('home')
    
def update(request,update_id):
    Student = student.objects.get(id=update_id)
    if request.method == 'POST':
        name = request.POST['name']
        address = request.POST['address']
        rank = request.POST['rank']
        # Student.name=name
        # Student.address=address
        # Student.rank = rank
        Student=student.objects.create(name=name,address=address,rank=rank)
        Student.save()
        return redirect('home') 
    return render(request, 'update.html', {'student': Student})

    
 